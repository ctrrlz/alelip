import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['../assets/styles/app.component.css']
})
export class AppComponent {
  title = 'coffe-shop';
}
